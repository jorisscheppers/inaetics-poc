#include "../com32/lib/strtox.c"
