#include "../com32/lib/strntoumax.c"
