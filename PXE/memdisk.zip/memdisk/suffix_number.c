#include "../com32/lib/suffix_number.c"
